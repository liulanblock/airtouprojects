/**
 * Created by zengtao on 2017/10/18.
 */
import createHistory from 'history/createBrowserHistory';

export default createHistory();